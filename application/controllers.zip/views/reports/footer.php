<div class="col-md-12" style="line-height: 20px; margin-top: 30px; background: rgba(0,0,0,0.05); text-align: center !important;">
<p style="font-size: 11px !important; padding-left:20px; text-align:center !important;">Regional Office | Plaza # 91, Civic Center, Bahria Town Phase 4, Rawalpindi | 0331 2178621</p>
</div>