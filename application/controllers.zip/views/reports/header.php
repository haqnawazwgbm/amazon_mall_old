<table style="width: 100% !important;">
	<tr>
		<td width="30%">
			<img src="<?php echo base_url('assets/logo.png')?>" width="140" alt=""> <br> <br>
			<label for="" style="font-size: 11px; font-weight: bold'">Site Office:</label>
			<p style="font-size: 11px;">Near DHA-2 Gate 1, Main GT Road, Rawalpindi</p>
			<label for="" style="font-size: 11px; font-weight: bold'">Branch Office</label>
			<p style="font-size: 11px;">Office 1, Midway Commercial, Bahira Phase 7, Rawalpindi</p>
		</td>
		<td width="40%">
			
		</td>
		<td width="30%">
			<p style="font-size: 9px;">Date: <?php echo date("d M Y"); ?></p><br><br>
			<label style="font-size: 11px; font-weight: bold;">Contact Numbers</label>
			<p style="font-size: 11px;">051 873 7777</p>
			<p style="font-size: 11px;">051 517 2346</p>
		</td>
	</tr>
</table>
