#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `backup_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_location` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`backup_id`),
  UNIQUE KEY `backup_name_UNIQUE` (`backup_name`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: basic_floors
#

DROP TABLE IF EXISTS `basic_floors`;

CREATE TABLE `basic_floors` (
  `floor_id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_types` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `project_id` int(11) NOT NULL,
  `size_sqft` decimal(20,0) DEFAULT NULL,
  `price_sqft` varchar(200) NOT NULL,
  `rent_price` varchar(40) NOT NULL,
  PRIMARY KEY (`floor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (1, Lower Ground, 2018-01-24 11:15:56, 2018-01-24 07:32:39, 1, 18736, 28000, 175);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (2, Ground Floor, 2018-01-24 11:17:38, 0000-00-00 00:00:00, 1, 18736, 4000, 240);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (3, Mezzanine, 2018-01-24 11:19:09, 2018-01-24 07:32:57, 1, 18736, 28000, 175);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (4, 1st Floor, 2018-01-24 11:19:59, 2018-01-24 06:26:25, 1, 19109, 25000, 150);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (5, 2nd Floor, 2018-01-24 11:21:19, 2018-01-24 07:33:44, 1, 19109, 30000, 175);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (6, 3rd Floor+Mezzanine, 2018-01-24 11:23:17, 2018-01-24 07:33:07, 1, 16169, 10000, 100);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (7, 4th Floor, 2018-01-24 11:23:56, 2018-01-24 07:33:14, 1, 19109, 9000, 85);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (8, 5th Floor, 2018-01-24 11:24:59, 2018-01-24 07:33:21, 1, 19109, 11000, 100);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (9, 6th Floor, 2018-01-24 11:27:33, 2018-01-24 07:33:28, 1, 19109, 9000, 85);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (10, Roof Top, 2018-01-24 11:28:54, 2018-01-24 07:33:34, 1, 11854, 10000, 100);


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=246 DEFAULT CHARSET=utf8;

INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (1, AF, Afghanistan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (2, PK, Pakistan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (3, AE, United Arab Emirates);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (4, GB, United Kingdom);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (5, US, United States);


#
# TABLE STRUCTURE FOR: districts
#

DROP TABLE IF EXISTS `districts`;

CREATE TABLE `districts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `district_name` varchar(250) NOT NULL,
  `province_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=latin1;

INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (1, Attock, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (2, Attock, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (3, Lodhran, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (4, Bahawalnagar, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (5, Mandi Bahauddin, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (6, Bahawalpur, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (7, Mianwali, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (8, Bhakkar, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (9, Multan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (10, Chakwal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (11, Muzaffargarh, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (12, Chiniot, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (13, Narowal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (14, Dera Ghazi Khan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (15, Nankana Sahib, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (16, Faisalabad, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (17, Okara, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (18, Pakpattan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (19, Gujranwala, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (20, Gujrat, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (21, Hafizabad, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (22, Rajanpur, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (23, Jhang, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (24, Rahim Yar Khan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (25, Rawalpindi, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (26, Sahiwal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (27, Kasur, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (28, Sargodha, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (29, Khanewal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (30, Sheikhupura, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (31, Khushab, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (32, Sialkot, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (33, Lahore, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (34, Toba Tek Singh, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (35, Layyah, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (36, Vehari, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (59, Badin, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (60, Dadu, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (61, Ghotki, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (62, Hyderabad, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (63, Jacobabad, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (64, Jamshoro, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (65, Karachi, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (66, Kashmore, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (67, Khairpur, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (68, Larkana, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (69, Matiari, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (70, Mirpurkhas, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (71, Naushahro Firoz, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (72, Shaheed Benazirabad (Nawab Shah), 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (73, Qamber and Shahdad Kot, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (74, Sanghar, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (75, Shikarpur, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (76, Sukkur, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (77, Tando Allahyar, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (78, Hafizabad, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (79, Tando Muhammad Khan, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (80, Thatta, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (81, Umer Kot, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (82, Sujawal, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (83, Malir, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (84, Korangi, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (85, Sujawal, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (86, Lower Kohistan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (87, Torghar, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (88, Upper Dir, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (89, Tank, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (90, Swat, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (91, Swabi, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (92, Shangla, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (93, Peshawar, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (94, Nowshera, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (95, Mardan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (96, Mansehra, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (97, Malakand, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (98, Lower Dir, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (99, Lakki Marwat, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (100, Upper Kohistan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (101, Kohat, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (102, Haripur, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (103, Hangu, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (104, Dera Ismail Khan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (105, Chitral, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (106, Charsadda, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (107, Buner, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (108, Batagram, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (109, Bannu, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (110, Abbottabad, 3);


#
# TABLE STRUCTURE FOR: files
#

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `extension` varchar(50) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orignal_name` varchar(250) NOT NULL,
  `is_deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (1, Floor, 20180124062918003  LOWER GROUND FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 1, 2018-01-24 11:29:18, 003  LOWER GROUND FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (2, Floor, 20180124062956004  GROUND FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 2, 2018-01-24 11:29:56, 004  GROUND FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (3, Floor, 20180124063018005  MEZZANINE FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 3, 2018-01-24 11:30:18, 005  MEZZANINE FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (4, Floor, 20180124063036006  FIRST FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 4, 2018-01-24 11:30:36, 006  FIRST FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (5, Floor, 20180124063046007  SECOND FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 5, 2018-01-24 11:30:46, 007  SECOND FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (6, Floor, 20180124063059009  3RD FLOOR MEZZANINE PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 6, 2018-01-24 11:30:59, 009  3RD FLOOR MEZZANINE PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (7, Floor, 20180124063112010  4TH FLOOR OFFICE PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 7, 2018-01-24 11:31:12, 010  4TH FLOOR OFFICE PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (8, Floor, 20180124063133011  5TH FLOOR PLAN BUSINESS CENTER.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 8, 2018-01-24 11:31:33, 011  5TH FLOOR PLAN BUSINESS CENTER.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (9, Floor, 20180124063140012  6TH FLOOR OFFICE PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 9, 2018-01-24 11:31:40, 012  6TH FLOOR OFFICE PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (10, Floor, 20180124063147013  ROOF TOP RESTAURANT.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 10, 2018-01-24 11:31:47, 013  ROOF TOP RESTAURANT.pdf, N);


#
# TABLE STRUCTURE FOR: installments
#

DROP TABLE IF EXISTS `installments`;

CREATE TABLE `installments` (
  `installment_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double(20,0) NOT NULL,
  `remaining` double(20,0) NOT NULL,
  `paid` double(20,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sale_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `received_by` int(11) NOT NULL,
  `willberecievedon` varchar(20) NOT NULL,
  PRIMARY KEY (`installment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) NOT NULL,
  `data` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `column_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `department` varchar(100) NOT NULL,
  `urgency` enum('Normal','Urgent','Very Urgent') NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  `sent_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: payment_methods
#

DROP TABLE IF EXISTS `payment_methods`;

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `column_id` int(11) NOT NULL,
  `method` varchar(15) NOT NULL,
  `bank` varchar(150) NOT NULL,
  `cheque` varchar(100) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `pay_for` varchar(15) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: project
#

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(250) NOT NULL,
  `project_location` varchar(250) NOT NULL,
  `starting_date` date NOT NULL,
  `expected_end` date NOT NULL,
  `size_sqft` decimal(20,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `project` (`project_id`, `project_name`, `project_location`, `starting_date`, `expected_end`, `size_sqft`, `created_at`, `updated_at`) VALUES (1, Amazon Mall One, Near DHA-2 Gate 1 Main GT Road Islamabad , 2017-03-19, 2018-12-01, 4.00, 2018-01-24 09:29:59, 0000-00-00 00:00:00);


#
# TABLE STRUCTURE FOR: provinces
#

DROP TABLE IF EXISTS `provinces`;

CREATE TABLE `provinces` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `province_name` varchar(250) NOT NULL,
  `ct_id` int(11) NOT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (1, Punjab, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (2, Sindh, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (3, KP, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (4, Balochistan, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (5, Gilgit - Baltistan, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (6, FATA, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (7, Azad Jummu & Kashmir, 2);


#
# TABLE STRUCTURE FOR: relation
#

DROP TABLE IF EXISTS `relation`;

CREATE TABLE `relation` (
  `relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `relationship` varchar(250) NOT NULL,
  `relation_name` varchar(250) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`relation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sale
#

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `total_payment` double(20,0) NOT NULL,
  `token_money` double(20,0) NOT NULL,
  `down_payment` double(20,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `installments` varchar(20) NOT NULL,
  `added_by` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `recieved_token` int(11) NOT NULL,
  `recieved_downpayment` int(11) NOT NULL,
  `recieved_by` int(11) NOT NULL,
  `sale_date` date NOT NULL,
  `owners` varchar(200) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `discount` decimal(20,0) NOT NULL,
  `pricesqft` varchar(250) NOT NULL,
  PRIMARY KEY (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sale_documents
#

DROP TABLE IF EXISTS `sale_documents`;

CREATE TABLE `sale_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `document` varchar(50) NOT NULL,
  `file` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` varchar(250) NOT NULL,
  `orignal` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_units
#

DROP TABLE IF EXISTS `sales_units`;

CREATE TABLE `sales_units` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_type` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `floor_id` int(11) NOT NULL,
  `size_sqft` decimal(20,0) NOT NULL,
  `sold` int(11) NOT NULL,
  `sale_date` date NOT NULL,
  `shopID` varchar(200) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (1, Shop# 1, 2018-01-24 14:31:40, 0000-00-00 00:00:00, 0, 546, 0, 0000-00-00, AM-LG-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (2, Shop# 2, 2018-01-24 14:33:40, 0000-00-00 00:00:00, 1, 564, 0, 0000-00-00, AM-LG-S2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (3, Shop# 3, 2018-01-24 14:34:18, 0000-00-00 00:00:00, 1, 488, 0, 0000-00-00, AM-LG-S3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (4, Shop# 4, 2018-01-24 14:35:56, 0000-00-00 00:00:00, 1, 414, 0, 0000-00-00, AM-LG-S4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (5, Shop# 5, 2018-01-24 14:39:10, 0000-00-00 00:00:00, 1, 432, 0, 0000-00-00, AM-LG-S5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (6, Shop# 6, 2018-01-24 14:39:41, 0000-00-00 00:00:00, 1, 540, 0, 0000-00-00, AM-LG-S6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (7, Shop# 7, 2018-01-24 14:40:43, 0000-00-00 00:00:00, 1, 458, 0, 0000-00-00, AM-LG-S7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (8, Shop# 8, 2018-01-24 14:41:12, 0000-00-00 00:00:00, 1, 519, 0, 0000-00-00, AM-LG-S8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (9, Shop# 9, 2018-01-24 14:42:14, 0000-00-00 00:00:00, 1, 422, 0, 0000-00-00, AM-LG-S9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (10, Shop# 10, 2018-01-24 14:42:48, 0000-00-00 00:00:00, 1, 294, 0, 0000-00-00, AM-LG-S10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (11, Shop# 11, 2018-01-24 14:44:08, 0000-00-00 00:00:00, 1, 232, 0, 0000-00-00, AM-LG-S11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (12, Shop# 12, 2018-01-24 14:44:54, 0000-00-00 00:00:00, 1, 231, 0, 0000-00-00, AM-LG-S12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (13, Shop# 13, 2018-01-24 14:46:45, 0000-00-00 00:00:00, 1, 226, 0, 0000-00-00, AM-LG-S13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (14, Shop# 14, 2018-01-24 14:48:02, 0000-00-00 00:00:00, 1, 221, 0, 0000-00-00, AM-LG-S14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (15, Shop# 15, 2018-01-24 14:49:03, 0000-00-00 00:00:00, 1, 953, 0, 0000-00-00, AM-LG-S15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (16, Shop# 16, 2018-01-24 16:09:40, 0000-00-00 00:00:00, 1, 953, 0, 0000-00-00, AM-LG-S16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (17, Shop# 17, 2018-01-24 16:13:04, 0000-00-00 00:00:00, 1, 804, 0, 0000-00-00, AM-LG-S17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (18, Shop# 18, 2018-01-24 16:13:30, 0000-00-00 00:00:00, 1, 212, 0, 0000-00-00, AM-LG-S18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (19, Shop# 19, 2018-01-24 16:14:00, 0000-00-00 00:00:00, 1, 223, 0, 0000-00-00, AM-LG-S19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (20, Shop# 20, 2018-01-24 16:14:34, 0000-00-00 00:00:00, 1, 277, 0, 0000-00-00, AM-LG-S20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (21, Shop# 21, 2018-01-24 16:15:12, 0000-00-00 00:00:00, 1, 280, 0, 0000-00-00, AM-LG-S21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (22, Shop# 22, 2018-01-24 16:15:58, 0000-00-00 00:00:00, 1, 316, 0, 0000-00-00, AM-LG-S22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (23, Shop# 24, 2018-01-24 16:16:35, 0000-00-00 00:00:00, 1, 511, 0, 0000-00-00, AM-LG-S24);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (24, Shop# 25, 2018-01-24 16:17:32, 0000-00-00 00:00:00, 1, 377, 0, 0000-00-00, AM-LG-S25);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (25, Shop# 26, 2018-01-24 16:18:11, 0000-00-00 00:00:00, 1, 406, 0, 0000-00-00, AM-LG-S26);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (26, Shop# 27, 2018-01-24 16:22:24, 0000-00-00 00:00:00, 1, 473, 0, 0000-00-00, AM-LG-S27);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (27, Shop# 28, 2018-01-24 16:22:53, 0000-00-00 00:00:00, 1, 280, 0, 0000-00-00, AM-LG-S28);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (28, Shop# 29, 2018-01-24 16:23:46, 0000-00-00 00:00:00, 1, 464, 0, 0000-00-00, AM-LG-S29);


#
# TABLE STRUCTURE FOR: session
#

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `session_id` varchar(45) NOT NULL,
  `ip_address` varchar(20) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL,
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: takeback
#

DROP TABLE IF EXISTS `takeback`;

CREATE TABLE `takeback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(24,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: unit_changes
#

DROP TABLE IF EXISTS `unit_changes`;

CREATE TABLE `unit_changes` (
  `unit_change_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) NOT NULL,
  `change_in_size` decimal(20,0) NOT NULL,
  `change_in_price` decimal(20,0) NOT NULL,
  `change_in_tprice` decimal(20,0) NOT NULL,
  `authorized_files` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`unit_change_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (1, 32, 489, 0, 0, s, 2018-01-24 16:37:45, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (2, 31, 433, 0, 0, s, 2018-01-24 16:39:46, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (3, 1, 546, 0, 0, s, 2018-01-24 17:16:45, 0);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) NOT NULL,
  `title` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `phone_login` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `token` varchar(60) NOT NULL,
  `porfile_pic` varchar(250) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `type` enum('Admin','Agent','User','Accountant','Owners') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (30, Amazon, Mr., Islamabad, 2, Punjab, 1, Islamabad, 2, 3361964975, 3361964975, amazon@gmail.com, 21232f297a57a5a743894a0e4a801fc3, 2017-12-18, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (34, Iffat, Miss., F8 Islamabad, 2, 1, 25, Islamabad, 2, 3335354159, 0, iffat.kanwal@graana.com, 18656694a9deec490fb01d91046dc5b8, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (35, Farhana Akbar, Miss., F8 , 2, 1, 25, Islamabad, 2, 3335354159, 0, farhana.akbar@graana.com, 758d41af5cd7aae271e7db8a9261e7ce, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (37, Allauddin, Mr., Islamabad, 2, 3, 90, Swat, 2, 3438992212, , allauddin2015@gmail.com, a3f02d260085a757591afe6d903f28ab, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (38, Haseeb, Mr., Islamabad, 2, 1, 25, Islamabad, 2, 3361964975, , haseeb.khattak@graana.com, 81c9bea98eab136f45808d4599e0e7e0, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);


