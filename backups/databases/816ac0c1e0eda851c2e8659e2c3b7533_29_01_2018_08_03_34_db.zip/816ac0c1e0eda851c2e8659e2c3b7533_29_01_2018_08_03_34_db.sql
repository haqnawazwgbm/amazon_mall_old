#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `backup_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `backup_name` varchar(255) NOT NULL,
  `backup_location` varchar(255) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`backup_id`),
  UNIQUE KEY `backup_name_UNIQUE` (`backup_name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

INSERT INTO `backup` (`backup_id`, `backup_name`, `backup_location`, `created_date`) VALUES (29, 0054dc06c979d5bc126f4aae26602086_24_01_2018_12_17_24_db.zip, backups/databases/, 2018-01-24 12:17:24);


#
# TABLE STRUCTURE FOR: basic_floors
#

DROP TABLE IF EXISTS `basic_floors`;

CREATE TABLE `basic_floors` (
  `floor_id` int(11) NOT NULL AUTO_INCREMENT,
  `floor_types` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `project_id` int(11) NOT NULL,
  `size_sqft` decimal(20,0) DEFAULT NULL,
  `price_sqft` decimal(20,2) NOT NULL,
  `rent_price` varchar(40) NOT NULL,
  PRIMARY KEY (`floor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (1, Lower Ground, 2018-01-24 11:15:56, 2018-01-24 07:32:39, 1, 18736, 28000.00, 175);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (2, Ground Floor, 2018-01-24 11:17:38, 2018-01-25 05:36:05, 1, 18736, 40000.00, 240);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (3, Mezzanine, 2018-01-24 11:19:09, 2018-01-24 07:32:57, 1, 18736, 28000.00, 175);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (4, 1st Floor, 2018-01-24 11:19:59, 2018-01-24 06:26:25, 1, 19109, 25000.00, 150);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (5, 2nd Floor, 2018-01-24 11:21:19, 2018-01-24 07:33:44, 1, 19109, 30000.00, 175);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (6, 3rd Floor+Mezzanine, 2018-01-24 11:23:17, 2018-01-24 07:33:07, 1, 16169, 10000.00, 100);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (7, 4th Floor, 2018-01-24 11:23:56, 2018-01-24 07:33:14, 1, 19109, 9000.00, 85);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (8, 5th Floor, 2018-01-24 11:24:59, 2018-01-24 07:33:21, 1, 19109, 11000.00, 100);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (9, 6th Floor, 2018-01-24 11:27:33, 2018-01-24 07:33:28, 1, 19109, 9000.00, 85);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (10, Roof Top Mezzanine, 2018-01-24 11:28:54, 2018-01-25 10:07:54, 1, 11854, 10000.00, 100);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (11, Roof Top , 2018-01-25 15:13:01, 0000-00-00 00:00:00, 1, 11854, 10000.00, 100);
INSERT INTO `basic_floors` (`floor_id`, `floor_types`, `created_at`, `updated_at`, `project_id`, `size_sqft`, `price_sqft`, `rent_price`) VALUES (12, 3rd Floor, 2018-01-25 16:19:02, 0000-00-00 00:00:00, 1, 19109, 10000.00, 100);


#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_code` varchar(2) NOT NULL DEFAULT '',
  `country_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=478 DEFAULT CHARSET=utf8;

INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (249, BS, Bahamas);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (2, PK, Pakistan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (248, AZ, Azerbaijan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (247, AT, Austria);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (246, AU, Australia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (250, BH, Bahrain);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (251, BD, Bangladesh);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (252, BB, Barbados);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (253, BY, Belarus);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (254, BE, Belgium);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (255, BZ, Belize);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (256, BJ, Benin);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (257, BM, Bermuda);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (258, BT, Bhutan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (259, BO, Bolivia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (260, BA, Bosnia and Herzegovina);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (261, BW, Botswana);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (262, BV, Bouvet Island);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (263, BR, Brazil);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (264, IO, British Indian Ocean Territory);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (265, BN, Brunei Darussalam);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (266, BG, Bulgaria);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (267, BF, Burkina Faso);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (268, BI, Burundi);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (269, KH, Cambodia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (270, CM, Cameroon);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (271, CA, Canada);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (272, CV, Cape Verde);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (273, KY, Cayman Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (274, CF, Central African Republic);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (275, TD, Chad);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (276, CL, Chile);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (277, CN, China);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (278, CX, Christmas Island);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (279, CC, Cocos (Keeling) Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (280, CO, Colombia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (281, KM, Comoros);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (282, CG, Congo);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (283, CK, Cook Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (284, CR, Costa Rica);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (285, HR, Croatia (Hrvatska));
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (286, CU, Cuba);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (287, CY, Cyprus);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (288, CZ, Czech Republic);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (289, DK, Denmark);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (290, DJ, Djibouti);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (291, DM, Dominica);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (292, DO, Dominican Republic);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (293, TP, East Timor);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (294, EC, Ecuador);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (295, EG, Egypt);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (296, SV, El Salvador);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (297, GQ, Equatorial Guinea);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (298, ER, Eritrea);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (299, EE, Estonia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (300, ET, Ethiopia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (301, FK, Falkland Islands (Malvinas));
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (302, FO, Faroe Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (303, FJ, Fiji);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (304, FI, Finland);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (305, FR, France);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (306, FX, France, Metropolitan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (307, GF, French Guiana);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (308, PF, French Polynesia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (309, TF, French Southern Territories);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (310, GA, Gabon);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (311, GM, Gambia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (312, GE, Georgia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (313, DE, Germany);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (314, GH, Ghana);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (315, GI, Gibraltar);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (316, GK, Guernsey);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (317, GR, Greece);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (318, GL, Greenland);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (319, GD, Grenada);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (320, GP, Guadeloupe);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (321, GU, Guam);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (322, GT, Guatemala);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (323, GN, Guinea);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (324, GW, Guinea-Bissau);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (325, GY, Guyana);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (326, HT, Haiti);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (327, HM, Heard and Mc Donald Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (328, HN, Honduras);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (329, HK, Hong Kong);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (330, HU, Hungary);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (331, IS, Iceland);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (332, IN, India);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (333, IM, Isle of Man);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (334, ID, Indonesia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (335, IR, Iran (Islamic Republic of));
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (336, IQ, Iraq);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (337, IE, Ireland);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (338, IL, Israel);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (339, IT, Italy);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (340, CI, Ivory Coast);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (341, JE, Jersey);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (342, JM, Jamaica);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (343, JP, Japan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (344, JO, Jordan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (345, KZ, Kazakhstan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (346, KE, Kenya);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (347, KI, Kiribati);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (348, KP, Korea, Democratic People's Republic of);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (349, KR, Korea, Republic of);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (350, XK, Kosovo);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (351, KW, Kuwait);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (352, KG, Kyrgyzstan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (353, LA, Lao People's Democratic Republic);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (354, LV, Latvia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (355, LB, Lebanon);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (356, LS, Lesotho);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (357, LR, Liberia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (358, LY, Libyan Arab Jamahiriya);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (359, LI, Liechtenstein);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (360, LT, Lithuania);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (361, LU, Luxembourg);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (362, MO, Macau);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (363, MK, Macedonia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (364, MG, Madagascar);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (365, MW, Malawi);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (366, MY, Malaysia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (367, MV, Maldives);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (368, ML, Mali);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (369, MT, Malta);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (370, MH, Marshall Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (371, MQ, Martinique);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (372, MR, Mauritania);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (373, MU, Mauritius);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (374, TY, Mayotte);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (375, MX, Mexico);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (376, FM, Micronesia, Federated States of);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (377, MD, Moldova, Republic of);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (378, MC, Monaco);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (379, MN, Mongolia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (380, ME, Montenegro);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (381, MS, Montserrat);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (382, MA, Morocco);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (383, MZ, Mozambique);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (384, MM, Myanmar);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (385, NA, Namibia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (386, NR, Nauru);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (387, NP, Nepal);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (388, NL, Netherlands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (389, AN, Netherlands Antilles);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (390, NC, New Caledonia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (391, NZ, New Zealand);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (392, NI, Nicaragua);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (393, NE, Niger);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (394, NG, Nigeria);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (395, NU, Niue);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (396, NF, Norfolk Island);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (397, MP, Northern Mariana Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (398, NO, Norway);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (399, OM, Oman);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (400, PW, Palau);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (401, PS, Palestine);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (402, PA, Panama);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (403, PG, Papua New Guinea);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (404, PY, Paraguay);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (405, PE, Peru);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (406, PH, Philippines);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (407, PN, Pitcairn);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (408, PL, Poland);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (409, PT, Portugal);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (410, PR, Puerto Rico);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (411, QA, Qatar);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (412, RE, Reunion);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (413, RO, Romania);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (414, RU, Russian Federation);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (415, RW, Rwanda);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (416, KN, Saint Kitts and Nevis);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (417, LC, Saint Lucia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (418, VC, Saint Vincent and the Grenadines);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (419, WS, Samoa);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (420, SM, San Marino);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (421, ST, Sao Tome and Principe);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (422, SA, Saudi Arabia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (423, SN, Senegal);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (424, RS, Serbia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (425, SC, Seychelles);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (426, SL, Sierra Leone);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (427, SG, Singapore);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (428, SK, Slovakia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (429, SI, Slovenia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (430, SB, Solomon Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (431, SO, Somalia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (432, ZA, South Africa);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (433, GS, South Georgia South Sandwich Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (434, ES, Spain);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (435, LK, Sri Lanka);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (436, SH, St. Helena);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (437, PM, St. Pierre and Miquelon);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (438, SD, Sudan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (439, SR, Suriname);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (440, SJ, Svalbard and Jan Mayen Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (441, SZ, Swaziland);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (442, SE, Sweden);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (443, CH, Switzerland);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (444, SY, Syrian Arab Republic);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (445, TW, Taiwan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (446, TJ, Tajikistan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (447, TZ, Tanzania, United Republic of);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (448, TH, Thailand);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (449, TG, Togo);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (450, TK, Tokelau);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (451, TO, Tonga);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (452, TT, Trinidad and Tobago);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (453, TN, Tunisia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (454, TR, Turkey);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (455, TM, Turkmenistan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (456, TC, Turks and Caicos Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (457, TV, Tuvalu);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (458, UG, Uganda);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (459, UA, Ukraine);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (460, AE, United Arab Emirates);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (461, GB, United Kingdom);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (462, US, United States);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (463, UM, United States minor outlying islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (464, UY, Uruguay);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (465, UZ, Uzbekistan);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (466, VU, Vanuatu);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (467, VA, Vatican City State);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (468, VE, Venezuela);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (469, VN, Vietnam);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (470, VG, Virgin Islands (British));
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (471, VI, Virgin Islands (U.S.));
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (472, WF, Wallis and Futuna Islands);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (473, EH, Western Sahara);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (474, YE, Yemen);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (475, ZR, Zaire);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (476, ZM, Zambia);
INSERT INTO `countries` (`id`, `country_code`, `country_name`) VALUES (477, ZW, Zimbabwe);


#
# TABLE STRUCTURE FOR: districts
#

DROP TABLE IF EXISTS `districts`;

CREATE TABLE `districts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `district_name` varchar(250) NOT NULL,
  `province_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=latin1;

INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (1, Attock, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (2, Attock, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (3, Lodhran, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (4, Bahawalnagar, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (5, Mandi Bahauddin, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (6, Bahawalpur, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (7, Mianwali, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (8, Bhakkar, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (9, Multan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (10, Chakwal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (11, Muzaffargarh, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (12, Chiniot, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (13, Narowal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (14, Dera Ghazi Khan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (15, Nankana Sahib, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (16, Faisalabad, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (17, Okara, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (18, Pakpattan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (19, Gujranwala, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (20, Gujrat, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (21, Hafizabad, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (22, Rajanpur, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (23, Jhang, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (24, Rahim Yar Khan, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (25, Rawalpindi, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (26, Sahiwal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (27, Kasur, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (28, Sargodha, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (29, Khanewal, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (30, Sheikhupura, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (31, Khushab, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (32, Sialkot, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (33, Lahore, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (34, Toba Tek Singh, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (35, Layyah, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (36, Vehari, 1);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (59, Badin, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (60, Dadu, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (61, Ghotki, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (62, Hyderabad, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (63, Jacobabad, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (64, Jamshoro, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (65, Karachi, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (66, Kashmore, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (67, Khairpur, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (68, Larkana, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (69, Matiari, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (70, Mirpurkhas, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (71, Naushahro Firoz, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (72, Shaheed Benazirabad (Nawab Shah), 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (73, Qamber and Shahdad Kot, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (74, Sanghar, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (75, Shikarpur, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (76, Sukkur, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (77, Tando Allahyar, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (78, Hafizabad, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (79, Tando Muhammad Khan, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (80, Thatta, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (81, Umer Kot, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (82, Sujawal, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (83, Malir, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (84, Korangi, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (85, Sujawal, 2);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (86, Lower Kohistan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (87, Torghar, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (88, Upper Dir, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (89, Tank, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (90, Swat, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (91, Swabi, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (92, Shangla, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (93, Peshawar, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (94, Nowshera, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (95, Mardan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (96, Mansehra, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (97, Malakand, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (98, Lower Dir, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (99, Lakki Marwat, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (100, Upper Kohistan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (101, Kohat, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (102, Haripur, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (103, Hangu, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (104, Dera Ismail Khan, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (105, Chitral, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (106, Charsadda, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (107, Buner, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (108, Batagram, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (109, Bannu, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (110, Abbottabad, 3);
INSERT INTO `districts` (`id`, `district_name`, `province_id`) VALUES (111, Islamabad, 8);


#
# TABLE STRUCTURE FOR: files
#

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `extension` varchar(50) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `orignal_name` varchar(250) NOT NULL,
  `is_deleted` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (1, Floor, 20180124062918003  LOWER GROUND FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 1, 2018-01-24 11:29:18, 003  LOWER GROUND FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (2, Floor, 20180124062956004  GROUND FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 2, 2018-01-24 11:29:56, 004  GROUND FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (3, Floor, 20180124063018005  MEZZANINE FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 3, 2018-01-24 11:30:18, 005  MEZZANINE FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (4, Floor, 20180124063036006  FIRST FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 4, 2018-01-24 11:30:36, 006  FIRST FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (5, Floor, 20180124063046007  SECOND FLOOR PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 5, 2018-01-24 11:30:46, 007  SECOND FLOOR PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (6, Floor, 20180124063059009  3RD FLOOR MEZZANINE PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 6, 2018-01-24 11:30:59, 009  3RD FLOOR MEZZANINE PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (7, Floor, 20180124063112010  4TH FLOOR OFFICE PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 7, 2018-01-24 11:31:12, 010  4TH FLOOR OFFICE PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (8, Floor, 20180124063133011  5TH FLOOR PLAN BUSINESS CENTER.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 8, 2018-01-24 11:31:33, 011  5TH FLOOR PLAN BUSINESS CENTER.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (9, Floor, 20180124063140012  6TH FLOOR OFFICE PLAN.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 9, 2018-01-24 11:31:40, 012  6TH FLOOR OFFICE PLAN.pdf, N);
INSERT INTO `files` (`id`, `type`, `filename`, `url`, `extension`, `type_id`, `created_at`, `orignal_name`, `is_deleted`) VALUES (10, Floor, 20180124063147013  ROOF TOP RESTAURANT.pdf, http://sales.amazonmall.pk/assets/uploads/files/, pdf, 10, 2018-01-24 11:31:47, 013  ROOF TOP RESTAURANT.pdf, N);


#
# TABLE STRUCTURE FOR: installments
#

DROP TABLE IF EXISTS `installments`;

CREATE TABLE `installments` (
  `installment_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` double(20,0) NOT NULL,
  `remaining` double(20,0) NOT NULL,
  `paid` double(20,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sale_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `received_by` int(11) NOT NULL,
  `willberecievedon` varchar(20) NOT NULL,
  PRIMARY KEY (`installment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(250) NOT NULL,
  `data` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `column_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `department` varchar(100) NOT NULL,
  `urgency` enum('Normal','Urgent','Very Urgent') NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  `sent_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: payment_methods
#

DROP TABLE IF EXISTS `payment_methods`;

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `column_id` int(11) NOT NULL,
  `method` varchar(15) NOT NULL,
  `bank` varchar(150) NOT NULL,
  `cheque` varchar(100) NOT NULL,
  `branch` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `pay_for` varchar(15) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: project
#

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(250) NOT NULL,
  `project_location` varchar(250) NOT NULL,
  `starting_date` date NOT NULL,
  `expected_end` date NOT NULL,
  `size_sqft` decimal(20,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `project` (`project_id`, `project_name`, `project_location`, `starting_date`, `expected_end`, `size_sqft`, `created_at`, `updated_at`) VALUES (1, Amazon Mall, Near DHA-2 Gate 1 Main GT Road Islamabad , 2017-03-19, 2018-12-01, 4.00, 2018-01-24 09:29:59, 0000-00-00 00:00:00);


#
# TABLE STRUCTURE FOR: provinces
#

DROP TABLE IF EXISTS `provinces`;

CREATE TABLE `provinces` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `province_name` varchar(250) NOT NULL,
  `ct_id` int(11) NOT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (1, Punjab, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (2, Sindh, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (3, KP, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (4, Balochistan, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (5, Gilgit - Baltistan, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (6, FATA, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (7, Azad Jummu & Kashmir, 2);
INSERT INTO `provinces` (`province_id`, `province_name`, `ct_id`) VALUES (8, Capital Territory , 2);


#
# TABLE STRUCTURE FOR: relation
#

DROP TABLE IF EXISTS `relation`;

CREATE TABLE `relation` (
  `relation_id` int(11) NOT NULL AUTO_INCREMENT,
  `relationship` varchar(250) NOT NULL,
  `relation_name` varchar(250) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`relation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `relation` (`relation_id`, `relationship`, `relation_name`, `user_id`, `created_at`) VALUES (1, Select Relationship, , 39, 2018-01-27 15:42:37);
INSERT INTO `relation` (`relation_id`, `relationship`, `relation_name`, `user_id`, `created_at`) VALUES (2, Daughter, Maryam Hussain, 40, 2018-01-27 15:47:59);
INSERT INTO `relation` (`relation_id`, `relationship`, `relation_name`, `user_id`, `created_at`) VALUES (3, Select Relationship, Maryam Iqbal, 41, 2018-01-27 16:00:44);


#
# TABLE STRUCTURE FOR: sale
#

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `total_payment` double(20,2) NOT NULL,
  `token_money` double(20,2) NOT NULL,
  `down_payment` double(20,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `installments` varchar(20) NOT NULL,
  `added_by` int(11) NOT NULL,
  `floor_id` int(11) NOT NULL,
  `recieved_token` int(11) NOT NULL,
  `recieved_downpayment` int(11) NOT NULL,
  `recieved_by` int(11) NOT NULL,
  `sale_date` date NOT NULL,
  `owners` varchar(200) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `discount` decimal(20,2) NOT NULL,
  `pricesqft` varchar(250) NOT NULL,
  PRIMARY KEY (`sale_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sale_documents
#

DROP TABLE IF EXISTS `sale_documents`;

CREATE TABLE `sale_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `document` varchar(50) NOT NULL,
  `file` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `url` varchar(250) NOT NULL,
  `orignal` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sales_units
#

DROP TABLE IF EXISTS `sales_units`;

CREATE TABLE `sales_units` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_type` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `floor_id` int(11) NOT NULL,
  `size_sqft` decimal(20,2) NOT NULL,
  `sold` int(11) NOT NULL,
  `sale_date` date NOT NULL,
  `shopID` varchar(200) NOT NULL,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=latin1;

INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (1, Shop# 1, 2018-01-24 14:31:40, 0000-00-00 00:00:00, 1, 545.65, 0, 0000-00-00, AM-LG-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (2, Shop# 2, 2018-01-24 14:33:40, 0000-00-00 00:00:00, 1, 563.95, 0, 0000-00-00, AM-LG-S2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (3, Shop# 3, 2018-01-24 14:34:18, 0000-00-00 00:00:00, 1, 487.88, 0, 0000-00-00, AM-LG-S3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (4, Shop# 4, 2018-01-24 14:35:56, 0000-00-00 00:00:00, 1, 413.92, 0, 0000-00-00, AM-LG-S4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (5, Shop# 5, 2018-01-24 14:39:10, 0000-00-00 00:00:00, 1, 431.88, 0, 0000-00-00, AM-LG-S5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (6, Shop# 6, 2018-01-24 14:39:41, 0000-00-00 00:00:00, 1, 540.19, 0, 0000-00-00, AM-LG-S6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (7, Shop# 7, 2018-01-24 14:40:43, 0000-00-00 00:00:00, 1, 457.62, 0, 0000-00-00, AM-LG-S7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (8, Shop# 8, 2018-01-24 14:41:12, 0000-00-00 00:00:00, 1, 519.01, 0, 0000-00-00, AM-LG-S8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (9, Shop# 9, 2018-01-24 14:42:14, 0000-00-00 00:00:00, 1, 421.59, 0, 0000-00-00, AM-LG-S9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (10, Shop# 10, 2018-01-24 14:42:48, 0000-00-00 00:00:00, 1, 294.27, 0, 0000-00-00, AM-LG-S10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (11, Shop# 11, 2018-01-24 14:44:08, 0000-00-00 00:00:00, 1, 232.18, 0, 0000-00-00, AM-LG-S11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (12, Shop# 12, 2018-01-24 14:44:54, 0000-00-00 00:00:00, 1, 230.89, 0, 0000-00-00, AM-LG-S12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (13, Shop# 13, 2018-01-24 14:46:45, 0000-00-00 00:00:00, 1, 226.05, 0, 0000-00-00, AM-LG-S13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (14, Shop# 14, 2018-01-24 14:48:02, 0000-00-00 00:00:00, 1, 221.20, 0, 0000-00-00, AM-LG-S14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (15, Shop# 15, 2018-01-24 14:49:03, 0000-00-00 00:00:00, 1, 216.86, 0, 0000-00-00, AM-LG-S15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (16, Shop# 16, 2018-01-24 16:09:40, 0000-00-00 00:00:00, 1, 952.99, 0, 0000-00-00, AM-LG-S16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (17, Shop# 17, 2018-01-24 16:13:04, 0000-00-00 00:00:00, 1, 804.30, 0, 0000-00-00, AM-LG-S17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (18, Shop# 18, 2018-01-24 16:13:30, 0000-00-00 00:00:00, 1, 211.58, 0, 0000-00-00, AM-LG-S18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (19, Shop# 19, 2018-01-24 16:14:00, 0000-00-00 00:00:00, 1, 223.28, 0, 0000-00-00, AM-LG-S19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (20, Shop# 20, 2018-01-24 16:14:34, 0000-00-00 00:00:00, 1, 276.50, 0, 0000-00-00, AM-LG-S20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (21, Shop# 21, 2018-01-24 16:15:12, 0000-00-00 00:00:00, 1, 280.18, 0, 0000-00-00, AM-LG-S21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (22, Shop# 22, 2018-01-24 16:15:58, 0000-00-00 00:00:00, 1, 316.32, 0, 0000-00-00, AM-LG-S22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (23, Shop# 24, 2018-01-24 16:16:35, 0000-00-00 00:00:00, 1, 510.62, 0, 0000-00-00, AM-LG-S24);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (24, Shop# 25, 2018-01-24 16:17:32, 0000-00-00 00:00:00, 1, 376.91, 0, 0000-00-00, AM-LG-S25);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (25, Shop# 26, 2018-01-24 16:18:11, 0000-00-00 00:00:00, 1, 406.26, 0, 0000-00-00, AM-LG-S26);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (26, Shop# 27, 2018-01-24 16:22:24, 0000-00-00 00:00:00, 1, 473.35, 0, 0000-00-00, AM-LG-S27);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (27, Shop# 28, 2018-01-24 16:22:53, 0000-00-00 00:00:00, 1, 279.89, 0, 0000-00-00, AM-LG-S28);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (28, Shop# 29, 2018-01-24 16:23:46, 0000-00-00 00:00:00, 1, 464.42, 0, 0000-00-00, AM-LG-S29);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (34, Shop# 1, 2018-01-24 17:19:34, 0000-00-00 00:00:00, 2, 493.63, 0, 0000-00-00, AM-GF-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (35, Shop# 2, 2018-01-24 17:20:25, 0000-00-00 00:00:00, 2, 488.72, 0, 0000-00-00, AM-GF-S2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (36, Shop# 3, 2018-01-24 17:20:56, 0000-00-00 00:00:00, 2, 432.74, 0, 0000-00-00, AM-GF-S3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (37, Shop# 4, 2018-01-24 17:21:32, 0000-00-00 00:00:00, 2, 413.92, 0, 0000-00-00, AM-GF-S4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (38, Shop# 5, 2018-01-24 17:23:16, 0000-00-00 00:00:00, 2, 431.88, 0, 0000-00-00, AM-GF-S5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (39, Shop# 23, 2018-01-24 17:23:51, 0000-00-00 00:00:00, 1, 557.76, 0, 0000-00-00, AM-LG-S23);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (40, Shop# 6, 2018-01-24 17:24:37, 0000-00-00 00:00:00, 2, 540.25, 0, 0000-00-00, AM-GF-S6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (41, Shop# 7, 2018-01-24 17:25:07, 0000-00-00 00:00:00, 2, 457.91, 0, 0000-00-00, AM-GF-S7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (42, Shop# 8, 2018-01-24 17:25:37, 0000-00-00 00:00:00, 2, 519.19, 0, 0000-00-00, AM-GF-S8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (43, Shop# 9, 2018-01-24 17:26:11, 0000-00-00 00:00:00, 2, 731.46, 0, 0000-00-00, AM-GF-S9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (44, Shop# 10, 2018-01-24 17:26:44, 0000-00-00 00:00:00, 2, 294.27, 0, 0000-00-00, AM-GF-S10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (45, Shop# 11, 2018-01-24 17:27:15, 0000-00-00 00:00:00, 2, 232.18, 0, 0000-00-00, AM-GF-S11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (46, Shop# 12, 2018-01-24 17:27:45, 0000-00-00 00:00:00, 2, 230.89, 0, 0000-00-00, AM-GF-S12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (47, Shop# 13, 2018-01-24 17:28:11, 0000-00-00 00:00:00, 2, 226.05, 0, 0000-00-00, AM-GF-S13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (48, Shop# 14, 2018-01-24 17:28:38, 0000-00-00 00:00:00, 2, 221.20, 0, 0000-00-00, AM-GF-S14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (49, Shop# 15, 2018-01-24 17:29:02, 0000-00-00 00:00:00, 2, 216.31, 0, 0000-00-00, AM-GF-S15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (50, Shop# 16, 2018-01-24 17:29:30, 0000-00-00 00:00:00, 2, 952.99, 0, 0000-00-00, AM-GF-S16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (51, Shop# 17, 2018-01-24 17:30:08, 0000-00-00 00:00:00, 2, 804.30, 0, 0000-00-00, AM-GF-S17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (52, Shop# 18, 2018-01-24 17:30:40, 0000-00-00 00:00:00, 2, 211.58, 0, 0000-00-00, AM-GF-S18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (53, Shop# 19, 2018-01-24 17:32:34, 0000-00-00 00:00:00, 2, 223.28, 0, 0000-00-00, AM-GF-S19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (54, Shop# 20, 2018-01-24 17:33:51, 0000-00-00 00:00:00, 2, 276.44, 0, 0000-00-00, AM-GF-S20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (55, Shop# 21, 2018-01-24 17:34:17, 0000-00-00 00:00:00, 2, 280.48, 0, 0000-00-00, AM-GF-S21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (56, Shop# 22, 2018-01-24 17:34:48, 0000-00-00 00:00:00, 2, 316.43, 0, 0000-00-00, AM-GF-S22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (57, Shop# 23, 2018-01-24 17:35:21, 0000-00-00 00:00:00, 2, 557.76, 0, 0000-00-00, AM-GF-S23);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (58, Shop# 24, 2018-01-24 17:36:06, 0000-00-00 00:00:00, 2, 510.80, 0, 0000-00-00, AM-GF-S24);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (59, Shop# 25, 2018-01-24 17:36:37, 0000-00-00 00:00:00, 2, 376.91, 0, 0000-00-00, AM-GF-S25);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (60, Shop# 26, 2018-01-24 17:37:06, 0000-00-00 00:00:00, 2, 406.33, 0, 0000-00-00, AM-GF-S26);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (61, Shop# 27, 2018-01-24 17:37:41, 0000-00-00 00:00:00, 2, 408.16, 0, 0000-00-00, AM-GF-S27);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (62, Shop# 28, 2018-01-24 17:38:08, 0000-00-00 00:00:00, 2, 409.94, 0, 0000-00-00, AM-GF-S28);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (63, Shop# 29, 2018-01-24 17:38:42, 0000-00-00 00:00:00, 2, 708.61, 0, 0000-00-00, AM-GF-S29);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (64, Shop# 1, 2018-01-25 12:48:03, 0000-00-00 00:00:00, 4, 469.40, 0, 0000-00-00, AM-1F-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (65, Shop# 2, 2018-01-25 12:48:49, 0000-00-00 00:00:00, 4, 428.72, 0, 0000-00-00, AM-1F-S2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (66, Shop# 3, 2018-01-25 12:49:19, 0000-00-00 00:00:00, 4, 437.67, 0, 0000-00-00, AM-1F-S3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (67, Shop# 4, 2018-01-25 12:49:55, 0000-00-00 00:00:00, 4, 443.60, 0, 0000-00-00, AM-1F-S4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (68, Shop# 5, 2018-01-25 12:50:55, 0000-00-00 00:00:00, 4, 461.97, 0, 0000-00-00, AM-1F-S5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (69, Shop# 6, 2018-01-25 12:51:28, 0000-00-00 00:00:00, 4, 576.72, 0, 0000-00-00, AM-1F-S6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (70, Shop# 7, 2018-01-25 12:52:05, 0000-00-00 00:00:00, 4, 482.89, 0, 0000-00-00, AM-1F-S7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (71, Shop# 8, 2018-01-25 12:52:44, 0000-00-00 00:00:00, 4, 542.20, 0, 0000-00-00, AM-1F-S8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (72, Shop# 9, 2018-01-25 12:53:15, 0000-00-00 00:00:00, 4, 421.59, 0, 0000-00-00, AM-1F-S9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (73, Shop# 10, 2018-01-25 12:53:56, 0000-00-00 00:00:00, 4, 294.27, 0, 0000-00-00, AM-1F-S10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (74, Shop# 11, 2018-01-25 12:54:21, 0000-00-00 00:00:00, 4, 232.11, 0, 0000-00-00, AM-1F-S11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (75, Shop# 12, 2018-01-25 12:54:58, 0000-00-00 00:00:00, 4, 230.89, 0, 0000-00-00, AM-1F-S12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (76, Shop# 13, 2018-01-25 12:55:31, 0000-00-00 00:00:00, 4, 226.05, 0, 0000-00-00, AM-1F-S13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (77, Shop# 14, 2018-01-25 12:56:27, 0000-00-00 00:00:00, 4, 221.20, 0, 0000-00-00, AM-1F-S14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (78, Shop# 15, 2018-01-25 12:57:06, 0000-00-00 00:00:00, 4, 216.31, 0, 0000-00-00, AM-1F-S15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (79, Shop# 16, 2018-01-25 13:02:01, 0000-00-00 00:00:00, 4, 952.99, 0, 0000-00-00, AM-1F-S16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (80, Shop# 17, 2018-01-25 13:02:43, 0000-00-00 00:00:00, 4, 804.30, 0, 0000-00-00, AM-1F-S17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (81, Shop# 18, 2018-01-25 13:03:20, 0000-00-00 00:00:00, 4, 211.58, 0, 0000-00-00, AM-1F-S18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (82, Shop# 19, 2018-01-25 13:04:37, 0000-00-00 00:00:00, 4, 223.28, 0, 0000-00-00, AM-1F-S19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (83, Shop# 20, 2018-01-25 13:05:12, 0000-00-00 00:00:00, 4, 276.90, 0, 0000-00-00, AM-1F-S20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (84, Shop# 21, 2018-01-25 13:05:56, 0000-00-00 00:00:00, 4, 280.60, 0, 0000-00-00, AM-1F-S21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (85, Shop# 22, 2018-01-25 13:06:43, 0000-00-00 00:00:00, 4, 316.43, 0, 0000-00-00, AM-1F-S22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (86, Shop# 23, 2018-01-25 13:07:25, 0000-00-00 00:00:00, 4, 557.76, 0, 0000-00-00, AM-1F-S23);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (87, Shop# 24, 2018-01-25 13:08:44, 0000-00-00 00:00:00, 4, 510.83, 0, 0000-00-00, AM-1F-S24);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (88, Shop# 25, 2018-01-25 13:09:34, 0000-00-00 00:00:00, 4, 376.99, 0, 0000-00-00, AM-1F-S25);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (89, Shop# 26, 2018-01-25 13:13:27, 0000-00-00 00:00:00, 4, 406.29, 0, 0000-00-00, AM-1F-S26);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (90, Shop# 27, 2018-01-25 13:14:03, 0000-00-00 00:00:00, 4, 386.16, 0, 0000-00-00, AM-1F-S27);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (91, Shop# 28, 2018-01-25 13:14:42, 0000-00-00 00:00:00, 4, 416.34, 0, 0000-00-00, AM-1F-s28);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (92, Shop# 29, 2018-01-25 13:19:28, 0000-00-00 00:00:00, 4, 607.65, 0, 0000-00-00, AM-1F-S29);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (93, Shop# 30, 2018-01-25 13:20:42, 0000-00-00 00:00:00, 4, 396.65, 0, 0000-00-00, AM-1F-S30);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (94, Shop# 1 , 2018-01-25 13:43:24, 0000-00-00 00:00:00, 4, 469.40, 0, 0000-00-00, AM-1F-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (95, Shop# 1, 2018-01-25 14:07:54, 0000-00-00 00:00:00, 0, 428.37, 0, 0000-00-00, AM-M1-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (96, Shop# 2, 2018-01-25 14:10:23, 0000-00-00 00:00:00, 3, 398.70, 0, 0000-00-00, AM-M1-S2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (97, Office# 1, 2018-01-25 14:10:34, 0000-00-00 00:00:00, 9, 617.00, 0, 0000-00-00, AM-6F-O1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (98, Shop# 3, 2018-01-25 14:10:52, 0000-00-00 00:00:00, 3, 407.63, 0, 0000-00-00, AM-M1-S3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (99, Office# 2, 2018-01-25 14:10:54, 0000-00-00 00:00:00, 9, 607.45, 0, 0000-00-00, AM-6F-O2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (100, Office# 3, 2018-01-25 14:11:13, 0000-00-00 00:00:00, 9, 617.20, 0, 0000-00-00, AM-6F-O3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (101, Shop# 4, 2018-01-25 14:11:20, 0000-00-00 00:00:00, 3, 413.92, 0, 0000-00-00, AM-M1-S4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (102, Shop# 5, 2018-01-25 14:11:41, 0000-00-00 00:00:00, 3, 431.91, 0, 0000-00-00, AM-M1-S5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (103, Office# 4, 2018-01-25 14:11:46, 0000-00-00 00:00:00, 9, 620.89, 0, 0000-00-00, AM-6F-O4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (104, Office# 5, 2018-01-25 14:12:04, 0000-00-00 00:00:00, 9, 657.50, 0, 0000-00-00, AM-6F-O5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (105, Shop# 6, 2018-01-25 14:12:09, 0000-00-00 00:00:00, 3, 540.23, 0, 0000-00-00, AM-M1-S6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (106, Office# 6, 2018-01-25 14:12:23, 0000-00-00 00:00:00, 9, 778.37, 0, 0000-00-00, AM-6F-O6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (107, Shop# 7, 2018-01-25 14:12:33, 0000-00-00 00:00:00, 3, 457.80, 0, 0000-00-00, AM-M1-S7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (108, Office# 7, 2018-01-25 14:12:54, 0000-00-00 00:00:00, 9, 565.31, 0, 0000-00-00, AM-6F-O7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (109, Office# 8, 2018-01-25 14:13:11, 0000-00-00 00:00:00, 9, 558.86, 0, 0000-00-00, AM-6F-O8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (110, Shop# 8, 2018-01-25 14:13:20, 0000-00-00 00:00:00, 3, 519.55, 0, 0000-00-00, AM-M1-S8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (111, Office# 9, 2018-01-25 14:13:28, 0000-00-00 00:00:00, 9, 784.05, 0, 0000-00-00, AM-6F-O9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (112, Shop# 9, 2018-01-25 14:13:48, 0000-00-00 00:00:00, 3, 421.59, 0, 0000-00-00, AM-M1-S9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (113, Office# 10, 2018-01-25 14:13:55, 0000-00-00 00:00:00, 9, 374.14, 0, 0000-00-00, AM-6F-O10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (114, Shop# 10, 2018-01-25 14:14:10, 0000-00-00 00:00:00, 3, 294.27, 0, 0000-00-00, AM-M1-S10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (115, Office# 11, 2018-01-25 14:14:16, 0000-00-00 00:00:00, 9, 508.43, 0, 0000-00-00, AM-6F-O11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (116, Office# 12, 2018-01-25 14:14:33, 0000-00-00 00:00:00, 9, 498.70, 0, 0000-00-00, AM-6F-O12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (117, Shop# 11, 2018-01-25 14:14:40, 0000-00-00 00:00:00, 3, 232.11, 0, 0000-00-00, AM-M1-S11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (118, Shop# 12, 2018-01-25 14:16:28, 0000-00-00 00:00:00, 3, 230.89, 0, 0000-00-00, AM-M1-S12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (119, Shop# 13, 2018-01-25 14:25:07, 0000-00-00 00:00:00, 3, 226.05, 0, 0000-00-00, AM-M1-S13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (120, Office# 13, 2018-01-25 14:25:46, 0000-00-00 00:00:00, 9, 492.28, 0, 0000-00-00, AM-6F-O13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (121, Office# 14, 2018-01-25 14:26:40, 0000-00-00 00:00:00, 9, 485.36, 0, 0000-00-00, AM-6F-O14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (122, Office# 15, 2018-01-25 14:27:02, 0000-00-00 00:00:00, 9, 477.52, 0, 0000-00-00, AM-6F-O15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (123, Office# 16, 2018-01-25 14:27:20, 0000-00-00 00:00:00, 9, 1125.06, 0, 0000-00-00, AM-6F-O16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (124, Office# 17, 2018-01-25 14:27:39, 0000-00-00 00:00:00, 9, 770.66, 0, 0000-00-00, AM-6F-O17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (125, Office# 18, 2018-01-25 14:30:33, 0000-00-00 00:00:00, 9, 697.98, 0, 0000-00-00, AM-6F-O18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (126, Office# 19, 2018-01-25 14:30:51, 0000-00-00 00:00:00, 9, 532.11, 0, 0000-00-00, AM-6F-O19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (127, Office# 20, 2018-01-25 14:31:18, 0000-00-00 00:00:00, 9, 573.28, 0, 0000-00-00, AM-6F-O20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (128, Office# 21, 2018-01-25 14:31:36, 0000-00-00 00:00:00, 9, 546.03, 0, 0000-00-00, AM-6F-O21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (129, Office# 22, 2018-01-25 14:31:58, 0000-00-00 00:00:00, 9, 587.98, 0, 0000-00-00, AM-6F-O22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (130, Office# 23, 2018-01-25 14:32:20, 0000-00-00 00:00:00, 9, 1044.80, 0, 0000-00-00, AM-6F-O23);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (131, Shop# 14, 2018-01-25 14:45:05, 0000-00-00 00:00:00, 3, 221.20, 0, 0000-00-00, AM-M1-S14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (132, Shop# 15, 2018-01-25 14:45:32, 0000-00-00 00:00:00, 3, 216.31, 0, 0000-00-00, AM-M1-S15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (133, Shop# 16, 2018-01-25 14:46:04, 0000-00-00 00:00:00, 3, 952.99, 0, 0000-00-00, AM-M1-S16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (134, Shop# 17, 2018-01-25 14:46:31, 0000-00-00 00:00:00, 3, 804.30, 0, 0000-00-00, AM-M1-S17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (135, Shop# 18, 2018-01-25 14:46:52, 0000-00-00 00:00:00, 3, 211.58, 0, 0000-00-00, AM-M1-S18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (136, Shop# 19, 2018-01-25 14:47:14, 0000-00-00 00:00:00, 3, 223.28, 0, 0000-00-00, AM-M1-S19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (137, Shop# 20, 2018-01-25 14:47:42, 0000-00-00 00:00:00, 3, 276.90, 0, 0000-00-00, AM-M1-S20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (138, Shop# 21, 2018-01-25 14:48:20, 0000-00-00 00:00:00, 3, 280.60, 0, 0000-00-00, AM-M1-S21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (139, Shop# 22, 2018-01-25 14:48:41, 0000-00-00 00:00:00, 3, 316.43, 0, 0000-00-00, AM-M1-S22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (140, Shop# 23, 2018-01-25 14:49:10, 0000-00-00 00:00:00, 3, 557.76, 0, 0000-00-00, AM-M1-S23);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (141, Shop# 24, 2018-01-25 14:49:36, 0000-00-00 00:00:00, 3, 510.83, 0, 0000-00-00, AM-M1-S24);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (142, Shop# 25, 2018-01-25 14:50:28, 0000-00-00 00:00:00, 3, 376.99, 0, 0000-00-00, AM-M1-S25);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (143, Shop# 26, 2018-01-25 14:50:59, 0000-00-00 00:00:00, 3, 406.29, 0, 0000-00-00, AM-M1-S26);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (144, Shop# 27, 2018-01-25 14:51:41, 0000-00-00 00:00:00, 3, 386.16, 0, 0000-00-00, AM-M1-S27);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (145, Shop# 28, 2018-01-25 14:52:01, 0000-00-00 00:00:00, 3, 416.34, 0, 0000-00-00, AM-M1-S28);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (146, Shop# 29, 2018-01-25 14:52:30, 0000-00-00 00:00:00, 3, 551.83, 0, 0000-00-00, AM-M1-S29);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (147, Shop# 30, 2018-01-25 14:53:03, 0000-00-00 00:00:00, 3, 351.83, 0, 0000-00-00, AM-M1-S30);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (148, Restaurant# 1A, 2018-01-25 14:54:34, 0000-00-00 00:00:00, 10, 722.65, 0, 0000-00-00, AM-RT-R1A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (149, Restaurant# 1B, 2018-01-25 14:55:17, 0000-00-00 00:00:00, 10, 1541.65, 0, 0000-00-00, AM-RT-R1B);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (150, Restaurant# 2A, 2018-01-25 14:56:38, 0000-00-00 00:00:00, 10, 874.69, 0, 0000-00-00, AM-RT-R2A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (151, Restaurant# 2B, 2018-01-25 14:57:05, 0000-00-00 00:00:00, 10, 2292.09, 0, 0000-00-00, AM-RT-R2B);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (152, Shop# 1, 2018-01-25 14:58:56, 0000-00-00 00:00:00, 5, 469.40, 0, 0000-00-00, AM-2F-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (153, Restaurant# 3A, 2018-01-25 14:59:05, 0000-00-00 00:00:00, 10, 920.30, 0, 0000-00-00, AM-RT-R3A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (154, Shop# 2, 2018-01-25 14:59:22, 0000-00-00 00:00:00, 5, 428.72, 0, 0000-00-00, AM-2F-S2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (155, Restaurant# 3B, 2018-01-25 14:59:44, 0000-00-00 00:00:00, 10, 575.27, 0, 0000-00-00, AM-RT-R3B);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (156, Shop# 3, 2018-01-25 14:59:49, 0000-00-00 00:00:00, 5, 437.67, 0, 0000-00-00, AM-2F-S3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (157, Shop# 4, 2018-01-25 15:00:11, 0000-00-00 00:00:00, 5, 443.60, 0, 0000-00-00, AM-2F-S4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (158, Restaurant# 4A, 2018-01-25 15:00:14, 0000-00-00 00:00:00, 10, 948.00, 0, 0000-00-00, AM-RT-R4A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (159, Shop# 5, 2018-01-25 15:00:44, 0000-00-00 00:00:00, 5, 461.97, 0, 0000-00-00, AM-2F-S5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (160, Shop# 6, 2018-01-25 15:01:28, 0000-00-00 00:00:00, 5, 576.72, 0, 0000-00-00, AM-2F-S6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (161, Shop# 7, 2018-01-25 15:01:48, 0000-00-00 00:00:00, 5, 417.72, 0, 0000-00-00, AM-2F-S7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (162, Shop# 8, 2018-01-25 15:02:12, 0000-00-00 00:00:00, 5, 420.27, 0, 0000-00-00, AM-2F-S8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (163, Shop# 9, 2018-01-25 15:02:58, 0000-00-00 00:00:00, 5, 1006.70, 0, 0000-00-00, AM-2F-S9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (164, Shop# 10, 2018-01-25 15:03:44, 0000-00-00 00:00:00, 5, 272.39, 0, 0000-00-00, AM-2F-S10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (165, Shop# 11, 2018-01-25 15:04:05, 0000-00-00 00:00:00, 5, 211.58, 0, 0000-00-00, AM-2F-S11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (166, Shop# 12, 2018-01-25 15:04:42, 0000-00-00 00:00:00, 5, 223.28, 0, 0000-00-00, AM-2F-S12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (167, Shop# 13, 2018-01-25 15:05:15, 0000-00-00 00:00:00, 5, 276.50, 0, 0000-00-00, AM-2F-S13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (168, Shop# 14, 2018-01-25 15:19:44, 0000-00-00 00:00:00, 5, 351.23, 0, 0000-00-00, AM-2F-S14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (169, Shop# 15, 2018-01-25 15:20:04, 0000-00-00 00:00:00, 5, 482.22, 0, 0000-00-00, AM-2F-S15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (170, Shop# 16, 2018-01-25 15:20:35, 0000-00-00 00:00:00, 5, 510.83, 0, 0000-00-00, AM-2F-S16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (171, Shop# 17, 2018-01-25 15:21:07, 0000-00-00 00:00:00, 5, 376.99, 0, 0000-00-00, AM-2F-S17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (172, Shop# 18, 2018-01-25 15:21:50, 0000-00-00 00:00:00, 5, 406.29, 0, 0000-00-00, AM-2F-S18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (173, Shop# 19, 2018-01-25 15:22:09, 0000-00-00 00:00:00, 5, 386.16, 0, 0000-00-00, AM-2F-S19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (174, Shop# 20, 2018-01-25 15:22:36, 0000-00-00 00:00:00, 5, 416.34, 0, 0000-00-00, AM-2F-S20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (175, Shop# 21, 2018-01-25 15:23:06, 0000-00-00 00:00:00, 5, 607.65, 0, 0000-00-00, AM-2F-S21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (176, Shop# 22, 2018-01-25 15:23:36, 0000-00-00 00:00:00, 5, 396.65, 0, 0000-00-00, AM-2F-S22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (177, Restaurant# 1, 2018-01-25 15:24:57, 0000-00-00 00:00:00, 11, 2637.22, 0, 0000-00-00, AM-RT-R1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (178, Restaurant# 2, 2018-01-25 15:25:25, 0000-00-00 00:00:00, 11, 2864.20, 0, 0000-00-00, AM-RT-R2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (179, Restaurant# 3, 2018-01-25 15:26:03, 0000-00-00 00:00:00, 11, 2815.03, 0, 0000-00-00, AM-RT-R3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (180, Restaurant# 4, 2018-01-25 15:26:27, 0000-00-00 00:00:00, 11, 3434.10, 0, 0000-00-00, AM-RT-R4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (181, Office# 1, 2018-01-25 15:29:48, 0000-00-00 00:00:00, 8, 444.43, 0, 0000-00-00, AM-5F-O1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (182, Office# 2, 2018-01-25 15:30:38, 0000-00-00 00:00:00, 8, 408.15, 0, 0000-00-00, AM-5F-O2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (183, Office# 3, 2018-01-25 15:30:58, 0000-00-00 00:00:00, 8, 417.00, 0, 0000-00-00, AM-5F-O3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (184, Restaurant# 01-A, 2018-01-25 15:31:12, 0000-00-00 00:00:00, 6, 1367.00, 0, 0000-00-00, AM-3F-R01-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (185, Office# 4, 2018-01-25 15:31:23, 0000-00-00 00:00:00, 8, 423.34, 0, 0000-00-00, AM-5F-O4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (186, Office# 5, 2018-01-25 15:31:59, 0000-00-00 00:00:00, 8, 452.51, 0, 0000-00-00, AM-5F-O5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (187, Restaurant# 02-A, 2018-01-25 15:32:17, 0000-00-00 00:00:00, 6, 1331.94, 0, 0000-00-00, AM-3F-R02-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (188, Office# 6, 2018-01-25 15:32:26, 0000-00-00 00:00:00, 8, 581.08, 0, 0000-00-00, AM-5F-O6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (189, Restaurant# 03-A, 2018-01-25 15:32:43, 0000-00-00 00:00:00, 6, 1422.12, 0, 0000-00-00, AM-3F-R03-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (190, Office# 7, 2018-01-25 15:32:52, 0000-00-00 00:00:00, 8, 437.83, 0, 0000-00-00, AM-5F-O7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (191, Restaurant# 04-A, 2018-01-25 15:33:14, 0000-00-00 00:00:00, 6, 1530.71, 0, 0000-00-00, AM-3F-R04-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (192, Office# 8, 2018-01-25 15:33:26, 0000-00-00 00:00:00, 8, 472.29, 0, 0000-00-00, AM-5F-O8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (193, Office# 9, 2018-01-25 15:33:51, 0000-00-00 00:00:00, 8, 448.72, 0, 0000-00-00, AM-5F-O9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (194, Office# 10, 2018-01-25 15:34:11, 0000-00-00 00:00:00, 8, 483.96, 0, 0000-00-00, AM-5F-O10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (195, Office# 11, 2018-01-25 15:34:33, 0000-00-00 00:00:00, 8, 727.61, 0, 0000-00-00, AM-5F-O11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (196, Restaurant# 05-A, 2018-01-25 15:34:41, 0000-00-00 00:00:00, 6, 1667.65, 0, 0000-00-00, AM-3F-R05-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (197, Restaurant# 06-A, 2018-01-25 15:35:13, 0000-00-00 00:00:00, 6, 1257.55, 0, 0000-00-00, AM-3F-R06-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (198, Board Room, 2018-01-25 15:36:03, 0000-00-00 00:00:00, 8, 588.10, 0, 0000-00-00, AM-5F-BRoom);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (199, Restaurant# 07-A, 2018-01-25 15:36:24, 0000-00-00 00:00:00, 6, 1803.81, 0, 0000-00-00, AM-3F-R07-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (200, SPA, 2018-01-25 15:36:30, 0000-00-00 00:00:00, 8, 1051.46, 0, 0000-00-00, AM-5F-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (201, Restaurant# 08-A, 2018-01-25 15:36:50, 0000-00-00 00:00:00, 6, 1143.14, 0, 0000-00-00, AM-3F-R08-A);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (202, Cafe, 2018-01-25 15:36:51, 0000-00-00 00:00:00, 8, 380.77, 0, 0000-00-00, AM-5F-C1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (203, Cafe# 1, 2018-01-25 15:37:12, 0000-00-00 00:00:00, 6, 743.55, 0, 0000-00-00, AM-3F-C1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (204, Conference Room, 2018-01-25 15:37:17, 0000-00-00 00:00:00, 8, 730.28, 0, 0000-00-00, AM-5F-CRoom);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (205, Training Room, 2018-01-25 15:37:50, 0000-00-00 00:00:00, 8, 1485.77, 0, 0000-00-00, AM-5F-TRoom);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (206, Cafe# 2, 2018-01-25 15:37:51, 0000-00-00 00:00:00, 6, 1388.82, 0, 0000-00-00, AM-3F-C2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (207, GYM, 2018-01-25 15:38:20, 0000-00-00 00:00:00, 8, 1782.31, 0, 0000-00-00, AM-5F-G1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (208, Office# 1, 2018-01-25 15:46:19, 0000-00-00 00:00:00, 7, 617.00, 0, 0000-00-00, AM-4F-O1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (209, Office# 2, 2018-01-25 15:47:17, 0000-00-00 00:00:00, 7, 607.45, 0, 0000-00-00, AM-4F-O2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (210, Office# 3, 2018-01-25 15:48:22, 0000-00-00 00:00:00, 7, 617.20, 0, 0000-00-00, AM-4F-O3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (211, Office# 4, 2018-01-25 15:48:55, 0000-00-00 00:00:00, 7, 620.89, 0, 0000-00-00, AM-4F-O4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (212, Office# 5, 2018-01-25 15:49:37, 0000-00-00 00:00:00, 7, 657.50, 0, 0000-00-00, AM-4F-O5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (213, Office# 6, 2018-01-25 15:50:06, 0000-00-00 00:00:00, 7, 778.37, 0, 0000-00-00, AM-4F-O6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (214, Office# 7, 2018-01-25 15:50:28, 0000-00-00 00:00:00, 7, 565.31, 0, 0000-00-00, AM-4F-O7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (215, Office# 8, 2018-01-25 15:51:10, 0000-00-00 00:00:00, 7, 558.86, 0, 0000-00-00, AM-4F-O8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (216, Office# 9, 2018-01-25 15:51:38, 0000-00-00 00:00:00, 7, 784.05, 0, 0000-00-00, AM-4F-O9);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (217, Office# 10, 2018-01-25 15:51:59, 0000-00-00 00:00:00, 7, 374.14, 0, 0000-00-00, AM-4F-O10);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (218, Office# 11, 2018-01-25 15:52:19, 0000-00-00 00:00:00, 7, 508.43, 0, 0000-00-00, AM-4F-O11);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (219, Office# 12, 2018-01-25 15:52:46, 0000-00-00 00:00:00, 7, 498.70, 0, 0000-00-00, AM-4F-O12);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (220, Office# 13, 2018-01-25 15:53:15, 0000-00-00 00:00:00, 7, 492.28, 0, 0000-00-00, AM-4F-O13);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (221, Office# 14, 2018-01-25 15:54:10, 0000-00-00 00:00:00, 7, 485.36, 0, 0000-00-00, AM-4F-O14);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (222, Office# 15, 2018-01-25 15:54:34, 0000-00-00 00:00:00, 7, 477.52, 0, 0000-00-00, AM-4F-O15);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (223, Office# 16, 2018-01-25 15:55:16, 0000-00-00 00:00:00, 7, 1125.06, 0, 0000-00-00, AM-4F-O16);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (224, Office# 17, 2018-01-25 15:55:39, 0000-00-00 00:00:00, 7, 770.66, 0, 0000-00-00, AM-4F-O17);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (225, Office# 18, 2018-01-25 15:56:09, 0000-00-00 00:00:00, 7, 697.98, 0, 0000-00-00, AM-4F-O18);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (226, Office# 19, 2018-01-25 15:56:34, 0000-00-00 00:00:00, 7, 532.11, 0, 0000-00-00, AM-4F-O19);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (227, Office# 20, 2018-01-25 15:57:00, 0000-00-00 00:00:00, 7, 573.28, 0, 0000-00-00, AM-4F-O20);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (228, Office# 21, 2018-01-25 15:57:25, 0000-00-00 00:00:00, 7, 546.03, 0, 0000-00-00, AM-4F-O21);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (229, Office# 22, 2018-01-25 15:57:52, 0000-00-00 00:00:00, 7, 587.98, 0, 0000-00-00, AM-4F-O22);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (230, Office# 23, 2018-01-25 15:58:16, 0000-00-00 00:00:00, 7, 1044.80, 0, 0000-00-00, AM-4F-O23);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (231, Shop# 1, 2018-01-25 16:04:31, 0000-00-00 00:00:00, 3, 428.37, 0, 0000-00-00, AM-M1-S1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (232, Restaurant# 1, 2018-01-25 16:31:01, 0000-00-00 00:00:00, 12, 1367.00, 0, 0000-00-00, AM-3F-R1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (233, Restaurant# 2, 2018-01-25 16:36:23, 0000-00-00 00:00:00, 12, 2043.50, 0, 0000-00-00, AM-3F-R2);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (234, Restaurant# 3, 2018-01-25 16:37:16, 0000-00-00 00:00:00, 12, 1432.16, 0, 0000-00-00, AM-3F-R3);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (235, Restaurant# 4, 2018-01-25 16:38:02, 0000-00-00 00:00:00, 12, 1731.43, 0, 0000-00-00, AM-3F-R4);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (236, Restaurant# 5, 2018-01-25 16:39:08, 0000-00-00 00:00:00, 12, 1426.65, 0, 0000-00-00, AM-3F-R5);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (237, Restaurant# 6, 2018-01-25 16:40:42, 0000-00-00 00:00:00, 12, 1739.71, 0, 0000-00-00, AM-3F-R6);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (238, Restaurant# 7, 2018-01-25 16:41:37, 0000-00-00 00:00:00, 12, 1357.85, 0, 0000-00-00, AM-3F-R7);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (239, Restaurant# 8, 2018-01-25 16:42:26, 0000-00-00 00:00:00, 12, 1143.14, 0, 0000-00-00, AM-3F-R8);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (240, Cafe, 2018-01-25 16:43:04, 0000-00-00 00:00:00, 12, 743.55, 0, 0000-00-00, AM-3F-C1);
INSERT INTO `sales_units` (`unit_id`, `unit_type`, `created_at`, `updated_at`, `floor_id`, `size_sqft`, `sold`, `sale_date`, `shopID`) VALUES (241, Kids Play Area, 2018-01-25 16:43:39, 0000-00-00 00:00:00, 12, 2798.20, 0, 0000-00-00, AM-3F-KPlay);


#
# TABLE STRUCTURE FOR: session
#

DROP TABLE IF EXISTS `session`;

CREATE TABLE `session` (
  `session_id` varchar(45) NOT NULL,
  `ip_address` varchar(20) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL,
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: takeback
#

DROP TABLE IF EXISTS `takeback`;

CREATE TABLE `takeback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(24,0) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: unit_changes
#

DROP TABLE IF EXISTS `unit_changes`;

CREATE TABLE `unit_changes` (
  `unit_change_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_id` int(11) NOT NULL,
  `change_in_size` decimal(20,0) NOT NULL,
  `change_in_price` decimal(20,0) NOT NULL,
  `change_in_tprice` decimal(20,0) NOT NULL,
  `authorized_files` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`unit_change_id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=latin1;

INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (1, 32, 489, 0, 0, s, 2018-01-24 16:37:45, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (2, 31, 433, 0, 0, s, 2018-01-24 16:39:46, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (3, 1, 546, 0, 0, s, 2018-01-24 17:16:45, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (4, 46, 231, 0, 0, s, 2018-01-24 17:31:41, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (5, 46, 231, 0, 0, s, 2018-01-24 17:33:24, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (6, 49, 216, 0, 0, s, 2018-01-24 17:40:44, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (7, 56, 316, 0, 0, s, 2018-01-24 17:41:46, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (8, 56, 316, 0, 0, s, 2018-01-24 18:13:03, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (9, 91, 416, 0, 0, s, 2018-01-25 13:15:48, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (10, 91, 416, 0, 0, s, 2018-01-25 13:17:59, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (11, 91, 416, 0, 0, s, 2018-01-25 13:18:25, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (12, 107, 458, 0, 0, s, 2018-01-25 14:13:04, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (13, 95, 428, 0, 0, s, 2018-01-25 14:34:55, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (14, 194, 484, 0, 0, s, 2018-01-25 15:41:14, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (15, 1, 546, 0, 0, s, 2018-01-25 16:14:01, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (16, 96, 399, 0, 0, s, 2018-01-27 11:56:27, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (17, 98, 408, 0, 0, s, 2018-01-27 11:58:43, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (18, 101, 414, 0, 0, s, 2018-01-27 11:59:13, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (19, 101, 414, 0, 0, s, 2018-01-27 11:59:13, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (20, 102, 432, 0, 0, s, 2018-01-27 11:59:48, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (21, 105, 540, 0, 0, s, 2018-01-27 12:00:20, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (22, 107, 458, 0, 0, s, 2018-01-27 12:00:42, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (23, 110, 520, 0, 0, s, 2018-01-27 12:01:18, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (24, 112, 422, 0, 0, s, 2018-01-27 12:01:44, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (25, 114, 294, 0, 0, s, 2018-01-27 12:02:09, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (26, 117, 232, 0, 0, s, 2018-01-27 12:03:12, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (27, 118, 231, 0, 0, s, 2018-01-27 12:03:38, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (28, 119, 226, 0, 0, s, 2018-01-27 12:06:28, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (29, 2, 564, 0, 0, s, 2018-01-27 12:15:23, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (30, 3, 488, 0, 0, s, 2018-01-27 12:15:45, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (31, 4, 414, 0, 0, s, 2018-01-27 12:16:29, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (32, 5, 432, 0, 0, s, 2018-01-27 12:16:51, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (33, 6, 540, 0, 0, s, 2018-01-27 12:17:09, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (34, 7, 458, 0, 0, s, 2018-01-27 12:20:08, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (35, 8, 519, 0, 0, s, 2018-01-27 12:20:30, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (36, 9, 422, 0, 0, s, 2018-01-27 12:21:09, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (37, 10, 294, 0, 0, s, 2018-01-27 12:21:52, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (38, 10, 294, 0, 0, s, 2018-01-27 12:22:14, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (39, 11, 232, 0, 0, s, 2018-01-27 12:22:47, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (40, 12, 231, 0, 0, s, 2018-01-27 12:23:38, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (41, 13, 226, 0, 0, s, 2018-01-27 12:24:33, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (42, 14, 221, 0, 0, s, 2018-01-27 12:24:52, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (43, 15, 953, 0, 0, s, 2018-01-27 12:26:03, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (44, 16, 953, 0, 0, s, 2018-01-27 12:26:39, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (45, 17, 804, 0, 0, s, 2018-01-27 12:27:02, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (46, 18, 212, 0, 0, s, 2018-01-27 12:27:25, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (47, 19, 223, 0, 0, s, 2018-01-27 12:28:03, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (48, 20, 277, 0, 0, s, 2018-01-27 12:28:44, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (49, 21, 280, 0, 0, s, 2018-01-27 12:29:09, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (50, 22, 316, 0, 0, s, 2018-01-27 12:32:31, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (51, 23, 511, 0, 0, s, 2018-01-27 12:34:03, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (52, 24, 377, 0, 0, s, 2018-01-27 12:34:42, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (53, 25, 406, 0, 0, s, 2018-01-27 12:35:17, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (54, 26, 473, 0, 0, s, 2018-01-27 12:36:26, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (55, 27, 280, 0, 0, s, 2018-01-27 12:37:46, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (56, 28, 464, 0, 0, s, 2018-01-27 12:38:25, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (57, 39, 558, 0, 0, s, 2018-01-27 12:38:48, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (58, 34, 494, 0, 0, s, 2018-01-27 12:41:24, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (59, 35, 489, 0, 0, s, 2018-01-27 12:42:05, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (60, 36, 433, 0, 0, s, 2018-01-27 12:42:33, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (61, 37, 414, 0, 0, s, 2018-01-27 12:43:06, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (62, 38, 432, 0, 0, s, 2018-01-27 12:43:46, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (63, 40, 540, 0, 0, s, 2018-01-27 12:44:18, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (64, 41, 458, 0, 0, s, 2018-01-27 12:45:32, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (65, 42, 519, 0, 0, s, 2018-01-27 12:46:11, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (66, 43, 731, 0, 0, s, 2018-01-27 12:50:38, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (67, 44, 294, 0, 0, s, 2018-01-27 12:51:03, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (68, 45, 232, 0, 0, s, 2018-01-27 12:54:01, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (69, 46, 231, 0, 0, s, 2018-01-27 12:55:40, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (70, 47, 226, 0, 0, s, 2018-01-27 12:56:11, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (71, 48, 221, 0, 0, s, 2018-01-27 12:57:13, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (72, 49, 216, 0, 0, s, 2018-01-27 12:57:52, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (73, 50, 953, 0, 0, s, 2018-01-27 12:58:12, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (74, 51, 804, 0, 0, s, 2018-01-27 12:58:37, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (75, 52, 212, 0, 0, s, 2018-01-27 12:59:01, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (76, 53, 223, 0, 0, s, 2018-01-27 13:00:29, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (77, 54, 276, 0, 0, s, 2018-01-27 13:01:07, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (78, 55, 280, 0, 0, s, 2018-01-27 13:01:37, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (79, 56, 316, 0, 0, s, 2018-01-27 13:02:30, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (80, 57, 558, 0, 0, s, 2018-01-27 13:03:02, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (81, 58, 511, 0, 0, s, 2018-01-27 13:03:41, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (82, 59, 377, 0, 0, s, 2018-01-27 13:04:09, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (83, 60, 406, 0, 0, s, 2018-01-27 13:04:46, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (84, 61, 408, 0, 0, s, 2018-01-27 13:05:19, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (85, 62, 510, 0, 0, s, 2018-01-27 13:05:45, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (86, 63, 709, 0, 0, s, 2018-01-27 13:06:18, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (87, 97, 617, 0, 0, s, 2018-01-27 13:07:36, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (88, 116, 499, 0, 0, s, 2018-01-27 13:11:08, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (89, 99, 607, 0, 0, s, 2018-01-27 14:25:21, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (90, 100, 617, 0, 0, s, 2018-01-27 14:25:46, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (91, 103, 621, 0, 0, s, 2018-01-27 14:26:20, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (92, 104, 658, 0, 0, s, 2018-01-27 14:27:01, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (93, 106, 778, 0, 0, s, 2018-01-27 14:27:47, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (94, 108, 565, 0, 0, s, 2018-01-27 14:28:28, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (95, 109, 559, 0, 0, s, 2018-01-27 14:29:38, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (96, 111, 784, 0, 0, s, 2018-01-27 14:30:33, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (97, 113, 374, 0, 0, s, 2018-01-27 14:31:20, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (98, 115, 508, 0, 0, s, 2018-01-27 14:33:19, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (99, 120, 492, 0, 0, s, 2018-01-27 14:35:37, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (100, 121, 485, 0, 0, s, 2018-01-27 14:36:22, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (101, 122, 478, 0, 0, s, 2018-01-27 14:37:02, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (102, 123, 1125, 0, 0, s, 2018-01-27 14:38:16, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (103, 124, 771, 0, 0, s, 2018-01-27 14:39:53, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (104, 64, 469, 0, 0, s, 2018-01-27 14:45:36, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (105, 65, 429, 0, 0, s, 2018-01-27 14:46:33, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (106, 66, 438, 0, 0, s, 2018-01-27 14:47:24, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (107, 67, 444, 0, 0, s, 2018-01-27 14:50:29, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (108, 68, 462, 0, 0, s, 2018-01-27 14:51:21, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (109, 69, 577, 0, 0, s, 2018-01-27 14:54:03, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (110, 81, 212, 0, 0, s, 2018-01-27 14:58:05, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (111, 94, 469, 0, 0, s, 2018-01-27 14:59:26, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (112, 87, 511, 0, 0, s, 2018-01-27 15:05:07, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (113, 70, 483, 0, 0, s, 2018-01-27 15:06:54, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (114, 71, 542, 0, 0, s, 2018-01-27 15:08:20, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (115, 72, 422, 0, 0, s, 2018-01-27 15:09:39, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (116, 73, 294, 0, 0, s, 2018-01-27 15:10:36, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (117, 74, 232, 0, 0, s, 2018-01-27 15:11:38, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (118, 75, 231, 0, 0, s, 2018-01-27 15:12:18, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (119, 76, 226, 0, 0, s, 2018-01-27 15:13:03, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (120, 77, 221, 0, 0, s, 2018-01-27 15:14:38, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (121, 78, 216, 0, 0, s, 2018-01-27 15:15:58, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (122, 79, 953, 0, 0, s, 2018-01-27 15:17:16, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (123, 80, 804, 0, 0, s, 2018-01-27 15:18:07, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (124, 82, 223, 0, 0, s, 2018-01-27 15:18:48, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (125, 83, 277, 0, 0, s, 2018-01-27 15:20:24, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (126, 84, 281, 0, 0, s, 2018-01-27 15:21:11, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (127, 85, 316, 0, 0, s, 2018-01-27 15:21:37, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (128, 86, 558, 0, 0, s, 2018-01-27 15:22:18, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (129, 88, 377, 0, 0, s, 2018-01-27 15:22:49, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (130, 89, 406, 0, 0, s, 2018-01-27 15:23:28, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (131, 90, 386, 0, 0, s, 2018-01-27 15:24:24, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (132, 91, 416, 0, 0, s, 2018-01-27 15:24:58, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (133, 92, 608, 0, 0, s, 2018-01-27 15:25:24, 0);
INSERT INTO `unit_changes` (`unit_change_id`, `unit_id`, `change_in_size`, `change_in_price`, `change_in_tprice`, `authorized_files`, `created_at`, `status`) VALUES (134, 93, 397, 0, 0, s, 2018-01-27 15:26:07, 0);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) NOT NULL,
  `title` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `country` varchar(50) NOT NULL,
  `province` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `phone_login` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `token` varchar(60) NOT NULL,
  `porfile_pic` varchar(250) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `type` enum('Admin','Agent','User','Accountant','Owners') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (30, Amazon, Mr., Islamabad, 2, Punjab, 1, Islamabad, 2, 3361964975, 3361964975, amazon@gmail.com, 21232f297a57a5a743894a0e4a801fc3, 2017-12-18, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (34, Iffat, Miss., F8 Islamabad, 2, 1, 25, Islamabad, 2, 3335354159, 0, iffat.kanwal@graana.com, 18656694a9deec490fb01d91046dc5b8, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (35, Farhana Akbar, Miss., F8 , 2, 1, 25, Islamabad, 2, 3335354159, 0, farhana.akbar@graana.com, 758d41af5cd7aae271e7db8a9261e7ce, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (37, Allauddin, Mr., Islamabad, 2, 3, 90, Swat, 2, 3438992212, , allauddin2015@gmail.com, a3f02d260085a757591afe6d903f28ab, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (38, Haseeb, Mr., Islamabad, 2, 1, 25, Islamabad, 2, 3361964975, , haseeb.khattak@graana.com, 81c9bea98eab136f45808d4599e0e7e0, 0000-00-00, 0000-00-00 00:00:00, , , 1, Admin);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (39, Faizan Ul Haq Lodhi, Mr., Islamabad, 2, 1, 7, Islamabad, Pakistan, 03325580961, 03325580961, haq_84@hotmail.com, b798c77b0fa8b53599487c702fad2138, 0000-00-00, 0000-00-00 00:00:00, , , 0, User);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (40, Saima Naeem, Mrs., House no 120, Street no 2, Race Course Road, Rawalpindi Cantt, 2, 1, 25, Rawalpindi, Pakistan, 03005169063, , symanaeem@hotmail.com, d343c74abca572fcd2262468268f92c5, 0000-00-00, 0000-00-00 00:00:00, , , 0, User);
INSERT INTO `users` (`user_id`, `fullname`, `title`, `address`, `country`, `province`, `district`, `city`, `nationality`, `phone_login`, `phone`, `email_id`, `password`, `created_at`, `updated_at`, `token`, `porfile_pic`, `status`, `type`) VALUES (41, Faizan Ul Haq LodhH, Mr., House no 407, Street 68, Pakistan Town Islamabad Highway, 2, 1, Select District, Islamabad, Pakistan, 03325580961, 0518355701, haq_84@hotmail.com, 281360c30d25b2dd4a3cce56a7ef404e, 0000-00-00, 0000-00-00 00:00:00, , , 0, User);


